﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsApp4.Services.Contract;
using WinFormsApp4.Models;

namespace WinFormsApp4.Services.Impl
{
   
    internal class ColourHachtService : IНachtService<Yahct>
    {
      

        public void Set(Yahct value)
        {
            
            
        }

       

        public void Update(Yahct value)
        {
            throw new NotImplementedException();
        }
    }
}
